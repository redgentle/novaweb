-----------------------------------------------------------------------------------------
Name��NOVA Middleware
Version: v1.0.4 beta
NOVA Middleware is a content management system.
-----------------------------------------------------------------------------------------
nova_db.sql---------Inital database for NOVA.
server--------------Web portal to manage the NVOA content and users.
client--------------Client part to show all the content to the set-top box.
-----------------------------------------------------------------------------------------
NOVA Middleware beta version is recommended to run in Ubuntu 12.04 LTS or Ubuntu 14.04 LTS system.
STEP 1: Install some system components by:
				apt-get install mysql-server mysql-client
				apt-get install apache2
				apt-get install php5 libapache2-mod-php5
				apt-get install php5-mysql php5-curl php5-gd php5-idn php-pear php5-imagick php5-imap php5-mcrypt php5-memcache php5-ming php5-ps php5-pspell php5-recode php5-snmp php5-sqlite php5-tidy php5-xmlrpc php5-xsl
				service apache2 restart
STEP 2: Import the nova_db.sql the Mysql database.
				Some example about how to setup the database like:
				mysql -u root -p
				>>>>>>input the password durint Mysql installation
				create database nova_db;
				use nova_db;
				source nova_db.sql;
STEP 3: Make a directory "nova" in apache2 root directory, it is usually like "/var/www".
        Unzip the "client.zip" file and "portal.zip" file to "nova" directory.
        Modify the "db.php" file to set the nova_db access password. Following three "db.php" files configure the access right each for client, billing system, middleware system.
        Please modify all these file according your server setup.
        		"nova/client/inc/db.php"
        		"nova/portal/billing/inc/db.php"
        		"nova/portal/middleware/inc/db.php"
STEP 4: Install the ioncuble loader for nova portal management. It is for encrypting the URL and User Account.
				Please refer to "How to install the ioncube_loader.txt.txt" file about how to install it and how to user the portal part.
STEP 5: If all the steps are correct, we could start to manage the nova_db by NOVA portal.
				Once all the content, user account and user credit are set, we could start trying to watch the NOVA content in Tvonline 4K boxes.
				Please input the server URL in the server setting, Tvonline 4K will automatically analyze the server URL and go to NOVA.
				
				
Note: 
(1)   If you get some http 500 error issue to remote access the portal webpages, pls check your php version, 
			and replace the "portal/billing/inc/nova.php" and "portal/middleware/inc/nova.php" files with the "nova_for_php5.3.php" or "nova_for_php5.5.php" according to your php version.			
(2)		The "client" and "portal" directory are suggested to be put under "/var/www" or "/var/www/html" directory.
(3)   The nova directory is suggested to be located as "/var/www/nova/client" and "/var/www/nova/portal", so the server url will be like "xxx.xxx.xxx.xxx/nova/client"
(4)   For the IMDB function to download the thumbnails for VOD, it's suggested to run "chmod 777 images -R" to give the nova/client/images directory writing right.
(5)   For using the excel loader function in NOVA, it's suggested to run "chmod 777 excel" to give the "nova/portal/billing/billing/excel"
      and "nova/portal/middleware/middleware/excel" writing right.
				


