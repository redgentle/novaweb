--------------------------------------------------
The portal part is for manage the nova database.
It need the ioncube to be preinstalled.
The portal has two parts, billing system and middleware system.
The Middleware system should be control by the content provider.
The Billing system is for user account and user credit management.
The content provider could give dealers to some right to manager each of his own users by web portal.
--------------------------------------------------

	