-- MySQL dump 10.13  Distrib 5.5.46, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nova_db
-- ------------------------------------------------------
-- Server version	5.5.46-0ubuntu0.12.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_category_main`
--

DROP TABLE IF EXISTS `app_category_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_category_main` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `CSort` int(11) NOT NULL,
  `CategoryName` varchar(255) NOT NULL,
  `Picturename` text NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_category_main`
--

LOCK TABLES `app_category_main` WRITE;
/*!40000 ALTER TABLE `app_category_main` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_category_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_category_sub`
--

DROP TABLE IF EXISTS `app_category_sub`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_category_sub` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryTID` int(11) NOT NULL,
  `SSort` int(11) NOT NULL,
  `SubCategory` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Picturename` text NOT NULL,
  `AlphaValue` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_category_sub`
--

LOCK TABLES `app_category_sub` WRITE;
/*!40000 ALTER TABLE `app_category_sub` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_category_sub` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_category_sub2`
--

DROP TABLE IF EXISTS `app_category_sub2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_category_sub2` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryTID` int(11) NOT NULL,
  `SSort` int(11) NOT NULL,
  `SubCategory` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Picturename` text NOT NULL,
  `AlphaValue` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_category_sub2`
--

LOCK TABLES `app_category_sub2` WRITE;
/*!40000 ALTER TABLE `app_category_sub2` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_category_sub2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_credits`
--

DROP TABLE IF EXISTS `b_credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_credits` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `UserTID` int(11) NOT NULL,
  `CerditsType` varchar(10) NOT NULL COMMENT 'Transfer, Pull',
  `TargetUserTID` int(11) NOT NULL,
  `Credits` int(11) NOT NULL,
  `Note` text NOT NULL,
  `Registration_Date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_credits`
--

LOCK TABLES `b_credits` WRITE;
/*!40000 ALTER TABLE `b_credits` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_credits_log`
--

DROP TABLE IF EXISTS `b_credits_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_credits_log` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `UserTID` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `TargetTID` int(11) NOT NULL,
  `TargetName` varchar(50) NOT NULL,
  `Details` varchar(100) NOT NULL,
  `Note` text NOT NULL,
  `RegDate` datetime NOT NULL,
  PRIMARY KEY (`TID`),
  KEY `MemberTID` (`UserTID`,`RegDate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_credits_log`
--

LOCK TABLES `b_credits_log` WRITE;
/*!40000 ALTER TABLE `b_credits_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_credits_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_member`
--

DROP TABLE IF EXISTS `b_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_member` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(50) NOT NULL,
  `UserPW` varchar(50) NOT NULL,
  `UserLevel` int(11) NOT NULL COMMENT 'Master(0),Submaster(1), Master(2), User(3)',
  `FullName` varchar(100) NOT NULL,
  `Tel` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `PullCreditsDisable` int(11) NOT NULL,
  `UnderTID` int(11) NOT NULL,
  `UnderName` varchar(50) NOT NULL,
  `Comments` text NOT NULL,
  `LastIP` varchar(20) NOT NULL,
  `LastDate` datetime NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Credits` int(11) NOT NULL,
  `Registration_Date` datetime NOT NULL,
  `PeriodEndDate` date NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_member`
--

LOCK TABLES `b_member` WRITE;
/*!40000 ALTER TABLE `b_member` DISABLE KEYS */;
INSERT INTO `b_member` VALUES (1,'novatester','novatester',0,'novatester','','','',0,1,'novatester','TEST\'s \r\n\"12345\"','192.168.25.42','2016-05-14 01:40:49','Active',9999,'2015-10-18 20:56:32','2016-05-11');
/*!40000 ALTER TABLE `b_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_member_log`
--

DROP TABLE IF EXISTS `b_member_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_member_log` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `MemberTID` int(11) NOT NULL,
  `ProgramName` varchar(100) NOT NULL,
  `Working` varchar(200) NOT NULL,
  `RegDate` datetime NOT NULL,
  PRIMARY KEY (`TID`),
  KEY `MemberTID` (`MemberTID`,`RegDate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_member_log`
--

LOCK TABLES `b_member_log` WRITE;
/*!40000 ALTER TABLE `b_member_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `b_member_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `b_message`
--

DROP TABLE IF EXISTS `b_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `b_message` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `MemberTID` int(11) NOT NULL,
  `MAC` text NOT NULL,
  `RetailerTID` int(11) NOT NULL,
  `RetailerName` varchar(50) NOT NULL,
  `Message` text NOT NULL,
  `Status` varchar(20) NOT NULL,
  `Registration_Date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_message`
--

LOCK TABLES `b_message` WRITE;
/*!40000 ALTER TABLE `b_message` DISABLE KEYS */;
INSERT INTO `b_message` VALUES (1,9,'0G43sILHAiM3X/+9CDgcPgIYKUJ9TQz/snty3ImdPpE=',1,'novatester','qqqbbb','Waiting','2016-06-02 21:57:43');
/*!40000 ALTER TABLE `b_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_main`
--

DROP TABLE IF EXISTS `category_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_main` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `CSort` int(11) NOT NULL,
  `CategoryName` varchar(255) NOT NULL,
  `Picturename` text NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_main`
--

LOCK TABLES `category_main` WRITE;
/*!40000 ALTER TABLE `category_main` DISABLE KEYS */;
INSERT INTO `category_main` VALUES (1,1,'Live',''),(2,2,'VOD',''),(3,3,'Audio','');
/*!40000 ALTER TABLE `category_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_sub`
--

DROP TABLE IF EXISTS `category_sub`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_sub` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryTID` int(11) NOT NULL,
  `SSort` int(11) NOT NULL,
  `SubCategory` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Picturename` text NOT NULL,
  `AlphaValue` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_sub`
--

LOCK TABLES `category_sub` WRITE;
/*!40000 ALTER TABLE `category_sub` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_sub` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_sub2`
--

DROP TABLE IF EXISTS `category_sub2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_sub2` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryTID` int(11) NOT NULL,
  `SSort` int(11) NOT NULL,
  `SubCategory` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Picturename` text NOT NULL,
  `AlphaValue` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_sub2`
--

LOCK TABLES `category_sub2` WRITE;
/*!40000 ALTER TABLE `category_sub2` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_sub2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_sub3`
--

DROP TABLE IF EXISTS `category_sub3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_sub3` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryTID` int(11) NOT NULL,
  `SSort` int(11) NOT NULL,
  `SubCategory` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Picturename` text NOT NULL,
  `AlphaValue` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_sub3`
--

LOCK TABLES `category_sub3` WRITE;
/*!40000 ALTER TABLE `category_sub3` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_sub3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_sub4`
--

DROP TABLE IF EXISTS `category_sub4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_sub4` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryTID` int(11) NOT NULL,
  `SSort` int(11) NOT NULL,
  `SubCategory` varchar(255) NOT NULL,
  `Description` text NOT NULL,
  `Picturename` text NOT NULL,
  `AlphaValue` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_sub4`
--

LOCK TABLES `category_sub4` WRITE;
/*!40000 ALTER TABLE `category_sub4` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_sub4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_app`
--

DROP TABLE IF EXISTS `channel_app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_app` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `AppName` varchar(255) NOT NULL,
  `Version` varchar(100) NOT NULL,
  `PackageName` varchar(100) NOT NULL,
  `Revision` varchar(100) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Distrbute` varchar(20) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `AutoInstall` varchar(10) NOT NULL,
  `HidingDevice` varchar(10) NOT NULL,
  `Price` varchar(100) NOT NULL,
  `Installs` varchar(100) NOT NULL,
  `Rating` varchar(100) NOT NULL,
  `FileURL` text NOT NULL,
  `FileName` varchar(255) NOT NULL,
  `FileSize` varchar(100) NOT NULL,
  `Description` text NOT NULL,
  `Language` varchar(100) NOT NULL,
  `Category1` varchar(100) NOT NULL,
  `Category2` varchar(100) NOT NULL,
  `Category3` varchar(100) NOT NULL,
  `thumbnail1` varchar(255) NOT NULL,
  `thumbnail2` varchar(255) NOT NULL,
  `thumbnail3` varchar(255) NOT NULL,
  `thumbnail4` varchar(255) NOT NULL,
  `Registration_date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_app`
--

LOCK TABLES `channel_app` WRITE;
/*!40000 ALTER TABLE `channel_app` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_app_language`
--

DROP TABLE IF EXISTS `channel_app_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_app_language` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `AppTID` int(11) NOT NULL,
  `TypeName` varchar(50) NOT NULL,
  `Description` text NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_app_language`
--

LOCK TABLES `channel_app_language` WRITE;
/*!40000 ALTER TABLE `channel_app_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_app_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_audio`
--

DROP TABLE IF EXISTS `channel_audio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_audio` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `ChName` varchar(100) NOT NULL,
  `ChNumber` varchar(10) NOT NULL,
  `Subtitle` varchar(100) NOT NULL,
  `SourceServer` int(11) NOT NULL,
  `Age` varchar(10) NOT NULL,
  `Rating` varchar(10) NOT NULL,
  `Volume` varchar(10) NOT NULL,
  `Bonus` varchar(10) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `PeriodPrice1` date NOT NULL,
  `PeriodPrice2` date NOT NULL,
  `PeriodPriceUnlimited` varchar(2) NOT NULL,
  `PeriodService1` date NOT NULL,
  `PeriodService2` date NOT NULL,
  `PeriodServiceUnlimited` varchar(2) NOT NULL,
  `IPGTime` varchar(10) NOT NULL,
  `IPGTID` int(11) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Genre` varchar(100) NOT NULL,
  `Category1` varchar(100) NOT NULL,
  `Category2` varchar(100) NOT NULL,
  `Category3` varchar(100) NOT NULL,
  `Category4` varchar(100) NOT NULL,
  `Category5` varchar(100) NOT NULL,
  `Comments` text NOT NULL,
  `Registration_date` datetime NOT NULL,
  `favorite` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_audio`
--

LOCK TABLES `channel_audio` WRITE;
/*!40000 ALTER TABLE `channel_audio` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_audio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_history`
--

DROP TABLE IF EXISTS `channel_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_history` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `SettopName` varchar(100) NOT NULL,
  `NickName` varchar(50) NOT NULL,
  `TariffTID` int(11) NOT NULL,
  `TariffName` varchar(100) NOT NULL,
  `ChannelTID` int(11) NOT NULL,
  `BroadCastingType` varchar(10) NOT NULL,
  `MetadataTitle` varchar(100) DEFAULT NULL,
  `Price` float DEFAULT '0',
  `UserIP` varchar(20) NOT NULL,
  `UserMAC` varchar(100) NOT NULL,
  `ServerTID` int(11) NOT NULL,
  `ServerNickName` varchar(100) NOT NULL,
  `ViewDateTime` datetime NOT NULL,
  PRIMARY KEY (`TID`),
  UNIQUE KEY `ServerCount` (`ServerTID`,`ViewDateTime`),
  KEY `SettopName` (`SettopName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_history`
--

LOCK TABLES `channel_history` WRITE;
/*!40000 ALTER TABLE `channel_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_live`
--

DROP TABLE IF EXISTS `channel_live`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_live` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `ChName` varchar(100) NOT NULL,
  `ChNumber` varchar(10) NOT NULL,
  `Subtitle` varchar(100) NOT NULL,
  `SourceServer` int(11) NOT NULL,
  `Age` varchar(10) NOT NULL,
  `Rating` varchar(10) NOT NULL,
  `Volume` varchar(10) NOT NULL,
  `Bonus` varchar(10) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `PeriodPrice1` date NOT NULL,
  `PeriodPrice2` date NOT NULL,
  `PeriodPriceUnlimited` varchar(2) NOT NULL,
  `PeriodService1` date NOT NULL,
  `PeriodService2` date NOT NULL,
  `PeriodServiceUnlimited` varchar(2) NOT NULL,
  `IPGTime` varchar(10) NOT NULL,
  `IPGTID` int(11) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Genre` varchar(100) NOT NULL,
  `Category1` varchar(100) NOT NULL,
  `Category2` varchar(100) NOT NULL,
  `Category3` varchar(100) NOT NULL,
  `Category4` varchar(100) NOT NULL,
  `Category5` varchar(100) NOT NULL,
  `Comments` text NOT NULL,
  `Registration_date` datetime NOT NULL,
  `favorite` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_live`
--

LOCK TABLES `channel_live` WRITE;
/*!40000 ALTER TABLE `channel_live` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_live` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_vod`
--

DROP TABLE IF EXISTS `channel_vod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel_vod` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `ChName` varchar(100) NOT NULL,
  `Subtitle` varchar(100) NOT NULL,
  `SourceServer` int(11) NOT NULL,
  `Age` varchar(10) NOT NULL,
  `Rating` varchar(10) NOT NULL,
  `Volume` varchar(10) NOT NULL,
  `Bonus` varchar(10) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `PeriodPrice1` date NOT NULL,
  `PeriodPrice2` date NOT NULL,
  `PeriodPriceUnlimited` varchar(2) NOT NULL,
  `PeriodService1` date NOT NULL,
  `PeriodService2` date NOT NULL,
  `PeriodServiceUnlimited` varchar(2) NOT NULL,
  `IPGTime` varchar(10) NOT NULL,
  `IPGTID` int(11) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Genre` varchar(100) NOT NULL,
  `Category1` varchar(100) NOT NULL,
  `Category2` varchar(100) NOT NULL,
  `Category3` varchar(100) NOT NULL,
  `Category4` varchar(100) NOT NULL,
  `Category5` varchar(100) NOT NULL,
  `Comments` text NOT NULL,
  `Registration_date` datetime NOT NULL,
  `favorite` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_vod`
--

LOCK TABLES `channel_vod` WRITE;
/*!40000 ALTER TABLE `channel_vod` DISABLE KEYS */;
/*!40000 ALTER TABLE `channel_vod` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipg_epg`
--

DROP TABLE IF EXISTS `ipg_epg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipg_epg` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `IPGName` varchar(100) NOT NULL,
  `ServerTID` int(11) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Picturename` text NOT NULL,
  `Registration_Date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipg_epg`
--

LOCK TABLES `ipg_epg` WRITE;
/*!40000 ALTER TABLE `ipg_epg` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipg_epg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipg_epg_program`
--

DROP TABLE IF EXISTS `ipg_epg_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipg_epg_program` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `IPGTID` int(11) NOT NULL,
  `PName` varchar(100) NOT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  `Description` text NOT NULL,
  `Registration_Date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipg_epg_program`
--

LOCK TABLES `ipg_epg_program` WRITE;
/*!40000 ALTER TABLE `ipg_epg_program` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipg_epg_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_authority`
--

DROP TABLE IF EXISTS `member_authority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_authority` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `MemberTID` int(11) NOT NULL,
  `ProgramName` varchar(100) NOT NULL,
  `Authority` varchar(1) NOT NULL,
  PRIMARY KEY (`TID`),
  KEY `MemberTID` (`MemberTID`,`ProgramName`)
) ENGINE=MyISAM AUTO_INCREMENT=1075 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_authority`
--

LOCK TABLES `member_authority` WRITE;
/*!40000 ALTER TABLE `member_authority` DISABLE KEYS */;
INSERT INTO `member_authority` VALUES (846,1011,'Middleware - Setup for Management Server','0'),(845,1011,'Middleware - Option','0'),(844,1011,'Middleware - Authority Initialize','0'),(843,1011,'Middleware - Administrator Accounts','0'),(842,1011,'Middleware - Default Settings','0'),(841,1011,'Middleware - SMS','0'),(840,1011,'Middleware - Playlist Creation','0'),(839,1011,'Middleware - IPG(EPG)','0'),(838,1011,'Middleware - Category','0'),(837,1011,'Middleware - Stream Servers','0'),(836,1011,'Middleware - News Setup','0'),(835,1011,'Middleware - Notice Setup','0'),(834,1011,'Middleware - Set-Top Control','0'),(1067,1000,'Middleware - SMS','1'),(1066,1000,'Middleware - Setup for Management Server','1'),(1065,1000,'Middleware - Set-Top Setting','1'),(1064,1000,'Middleware - Set-Top Control','1'),(1063,1000,'Middleware - Service Packages','1'),(1062,1000,'Middleware - Playlist Creation','1'),(1061,1000,'Middleware - Option','1'),(1060,1000,'Middleware - Notice Setup','1'),(1059,1000,'Middleware - News Setup','1'),(1058,1000,'Middleware - Live Channels','1'),(1057,1000,'Middleware - IPG(EPG)','1'),(1056,1000,'Middleware - Default Settings','1'),(1055,1000,'Middleware - DB Initialize','1'),(1054,1000,'Middleware - Category','1'),(833,1011,'Middleware - Set-Top Setting','0'),(832,1011,'Middleware - Tariffs Packages','0'),(831,1011,'Middleware - Service Packages','0'),(830,1011,'Middleware - Audio Channels','0'),(829,1011,'Middleware - VoD Channels','0'),(573,0,'Middleware - Live Channels','1'),(574,0,'Middleware - VoD Channels','1'),(575,0,'Middleware - Audio Channels','1'),(576,0,'Middleware - Service Packages','1'),(577,0,'Middleware - Tariffs Packages','1'),(578,0,'Middleware - Set-Top Setting','1'),(579,0,'Middleware - Set-Top Control','1'),(580,0,'Middleware - Notice Setup','1'),(581,0,'Middleware - News Setup','1'),(582,0,'Middleware - Stream Servers','1'),(583,0,'Middleware - Category','1'),(584,0,'Middleware - IPG(EPG)','1'),(585,0,'Middleware - Playlist Creation','1'),(586,0,'Middleware - SMS','1'),(587,0,'Middleware - Default Settings','1'),(588,0,'Middleware - Administrator Accounts','1'),(589,0,'Middleware - Authority Initialize','1'),(590,0,'Statistics - Rating','1'),(591,0,'Statistics - Set-Top Box','1'),(592,0,'Statistics - Stream Server','1'),(593,0,'Statistics - Total Count','1'),(594,0,'Middleware - Live Channels','0'),(595,0,'Middleware - VoD Channels','0'),(596,0,'Middleware - Audio Channels','0'),(597,0,'Middleware - Service Packages','0'),(598,0,'Middleware - Tariffs Packages','0'),(599,0,'Middleware - Set-Top Setting','0'),(600,0,'Middleware - Set-Top Control','0'),(601,0,'Middleware - Notice Setup','0'),(602,0,'Middleware - News Setup','0'),(603,0,'Middleware - Stream Servers','0'),(604,0,'Middleware - Category','0'),(605,0,'Middleware - IPG(EPG)','0'),(606,0,'Middleware - Playlist Creation','0'),(607,0,'Middleware - SMS','0'),(608,0,'Middleware - Default Settings','0'),(609,0,'Middleware - Administrator Accounts','0'),(610,0,'Middleware - Authority Initialize','0'),(611,0,'Statistics - Rating','0'),(612,0,'Statistics - Set-Top Box','0'),(613,0,'Statistics - Stream Server','0'),(614,0,'Statistics - Total Count','0'),(615,0,'Middleware - Live Channels','0'),(616,0,'Middleware - VoD Channels','0'),(617,0,'Middleware - Audio Channels','0'),(618,0,'Middleware - Service Packages','0'),(619,0,'Middleware - Tariffs Packages','0'),(620,0,'Middleware - Set-Top Setting','0'),(621,0,'Middleware - Set-Top Control','0'),(622,0,'Middleware - Notice Setup','0'),(623,0,'Middleware - News Setup','0'),(624,0,'Middleware - Stream Servers','0'),(625,0,'Middleware - Category','0'),(626,0,'Middleware - IPG(EPG)','0'),(627,0,'Middleware - Playlist Creation','0'),(628,0,'Middleware - SMS','0'),(629,0,'Middleware - Default Settings','0'),(630,0,'Middleware - Administrator Accounts','0'),(631,0,'Middleware - Authority Initialize','0'),(632,0,'Statistics - Rating','0'),(633,0,'Statistics - Set-Top Box','0'),(634,0,'Statistics - Stream Server','0'),(635,0,'Statistics - Total Count','0'),(1053,1000,'Middleware - Authority Initialize','1'),(828,1011,'Middleware - Live Channels','0'),(1052,1000,'Middleware - Audio Channels','1'),(1051,1000,'Middleware - App Channels','1'),(1050,1000,'Middleware - Administrator Accounts','1'),(847,1011,'Middleware - DB Initialize','0'),(848,1011,'Statistics - Rating','1'),(849,1011,'Statistics - Set-Top Box','1'),(850,1011,'Statistics - Stream Server','1'),(851,1011,'Statistics - Total Count','1'),(1074,1000,'Statistics - Total Count','1'),(1073,1000,'Statistics - Stream Server','1'),(1072,1000,'Statistics - Set-Top Box','1'),(1071,1000,'Statistics - Rating','1'),(1070,1000,'Middleware - VoD Channels','1'),(1068,1000,'Middleware - Stream Servers','1'),(1069,1000,'Middleware - Tariffs Packages','1');
/*!40000 ALTER TABLE `member_authority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_authority_init`
--

DROP TABLE IF EXISTS `member_authority_init`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_authority_init` (
  `TID` int(10) NOT NULL AUTO_INCREMENT,
  `ProgramName` varchar(100) NOT NULL,
  UNIQUE KEY `TID` (`TID`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_authority_init`
--

LOCK TABLES `member_authority_init` WRITE;
/*!40000 ALTER TABLE `member_authority_init` DISABLE KEYS */;
INSERT INTO `member_authority_init` VALUES (1,'Middleware - Live Channels'),(2,'Middleware - VoD Channels'),(3,'Middleware - Audio Channels'),(4,'Middleware - Service Packages'),(5,'Middleware - Tariffs Packages'),(6,'Middleware - Set-Top Setting'),(7,'Middleware - Set-Top Control'),(8,'Middleware - Notice Setup'),(9,'Middleware - News Setup'),(10,'Middleware - Stream Servers'),(11,'Middleware - Category'),(12,'Middleware - IPG(EPG)'),(13,'Middleware - Playlist Creation'),(14,'Middleware - SMS'),(15,'Middleware - Default Settings'),(16,'Middleware - Administrator Accounts'),(21,'Statistics - Rating'),(22,'Statistics - Set-Top Box'),(23,'Statistics - Stream Server'),(24,'Statistics - Total Count'),(17,'Middleware - Authority Initialize'),(18,'Middleware - Option'),(19,'Middleware - Setup for Management Server'),(20,'Middleware - DB Initialize'),(26,'Middleware - App Channels');
/*!40000 ALTER TABLE `member_authority_init` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_log`
--

DROP TABLE IF EXISTS `member_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_log` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `MemberTID` int(11) NOT NULL,
  `ProgramName` varchar(100) NOT NULL,
  `Working` varchar(200) NOT NULL,
  `RegDate` datetime NOT NULL,
  PRIMARY KEY (`TID`),
  KEY `MemberTID` (`MemberTID`,`RegDate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_log`
--

LOCK TABLES `member_log` WRITE;
/*!40000 ALTER TABLE `member_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memberadmin`
--

DROP TABLE IF EXISTS `memberadmin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memberadmin` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` varchar(50) NOT NULL,
  `UserPassword` varchar(50) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `ReceiveMessage` varchar(2) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Company` varchar(200) NOT NULL,
  `Tel` varchar(50) NOT NULL,
  `Cell` varchar(50) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Registration_date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM AUTO_INCREMENT=1017 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memberadmin`
--

LOCK TABLES `memberadmin` WRITE;
/*!40000 ALTER TABLE `memberadmin` DISABLE KEYS */;
INSERT INTO `memberadmin` VALUES (1000,'novatester','novatester','Administrator','novaadmin@avov.tv','1','LA','AVOV','111-1111-1111','010-1111-1111','ACTIVE','2015-09-12 10:00:00'),(1011,'avovtester','avovtester','Statistics','novaadmin@avov.tv','1','LA','AVOV','222-2222-2222','010-222-2222','ACTIVE','2015-09-12 10:00:00');
/*!40000 ALTER TABLE `memberadmin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `NewsName` varchar(100) NOT NULL,
  `NewsType` varchar(10) NOT NULL,
  `NewsURL` varchar(255) NOT NULL,
  `MustWatch` varchar(10) NOT NULL,
  `TariffPlan` varchar(100) NOT NULL,
  `PeriodService1` date NOT NULL,
  `PeriodService2` date NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Category1` varchar(100) NOT NULL,
  `Category2` varchar(100) NOT NULL,
  `Category3` varchar(100) NOT NULL,
  `Category4` varchar(100) NOT NULL,
  `Category5` varchar(100) NOT NULL,
  `Message` text NOT NULL,
  `Registration_Date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `NoticeName` varchar(100) NOT NULL,
  `NoticeType` varchar(10) NOT NULL,
  `NoticeURL` varchar(255) NOT NULL,
  `MustWatch` varchar(10) NOT NULL,
  `TariffPlan` varchar(100) NOT NULL,
  `PeriodService1` date NOT NULL,
  `PeriodService2` date NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Category1` varchar(100) NOT NULL,
  `Category2` varchar(100) NOT NULL,
  `Category3` varchar(100) NOT NULL,
  `Category4` varchar(100) NOT NULL,
  `Category5` varchar(100) NOT NULL,
  `Message` text NOT NULL,
  `Registration_Date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlist`
--

DROP TABLE IF EXISTS `playlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `playlist` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `PlayName` varchar(100) NOT NULL,
  `URL` varchar(255) NOT NULL,
  `Registration_Date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlist`
--

LOCK TABLES `playlist` WRITE;
/*!40000 ALTER TABLE `playlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `playlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlist_url`
--

DROP TABLE IF EXISTS `playlist_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `playlist_url` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `PTID` int(11) NOT NULL,
  `PSort` int(11) NOT NULL,
  `URL` text NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlist_url`
--

LOCK TABLES `playlist_url` WRITE;
/*!40000 ALTER TABLE `playlist_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `playlist_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_packages`
--

DROP TABLE IF EXISTS `service_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_packages` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `EID` varchar(100) NOT NULL,
  `PName` varchar(100) NOT NULL,
  `Service` varchar(10) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `All_Services` varchar(2) NOT NULL,
  `Registration_Date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_packages`
--

LOCK TABLES `service_packages` WRITE;
/*!40000 ALTER TABLE `service_packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_packages_selected`
--

DROP TABLE IF EXISTS `service_packages_selected`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_packages_selected` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `ETID` int(11) NOT NULL,
  `Service` varchar(10) NOT NULL,
  `ChannelTID` int(11) NOT NULL,
  `ChannelName` varchar(100) NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_packages_selected`
--

LOCK TABLES `service_packages_selected` WRITE;
/*!40000 ALTER TABLE `service_packages_selected` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_packages_selected` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settop_box`
--

DROP TABLE IF EXISTS `settop_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settop_box` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `SettopName` varchar(50) NOT NULL,
  `SettopPW` text NOT NULL,
  `NickName` varchar(50) DEFAULT NULL,
  `Sex` varchar(10) NOT NULL,
  `Birthday` date NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Resident` varchar(50) NOT NULL,
  `Add1` varchar(200) NOT NULL,
  `Tel` varchar(50) NOT NULL,
  `Cell` varchar(50) NOT NULL,
  `Check_Prepay` int(11) NOT NULL DEFAULT '0',
  `Sign` varchar(10) NOT NULL,
  `Prepay` int(11) NOT NULL DEFAULT '0',
  `CheckIn` varchar(10) NOT NULL,
  `CheckInTime` datetime NOT NULL,
  `CheckOutTime` datetime NOT NULL,
  `SettopKind` varchar(100) NOT NULL,
  `SettopMAC` text NOT NULL,
  `SettopIP` varchar(100) NOT NULL,
  `SettopPort` varchar(50) NOT NULL,
  `SettopSerial` text NOT NULL,
  `Status` varchar(10) NOT NULL,
  `LoginDefault` tinyint(4) NOT NULL DEFAULT '0',
  `GroupTID` varchar(10) NOT NULL,
  `GroupName` varchar(100) NOT NULL,
  `TariffTID` int(11) NOT NULL,
  `TariffName` varchar(100) NOT NULL,
  `UnderTID` int(11) NOT NULL,
  `UnderName` varchar(50) NOT NULL,
  `Reminder` varchar(10) NOT NULL,
  `Message` text NOT NULL,
  `LastIP` varchar(20) NOT NULL,
  `LastLogin` datetime NOT NULL,
  `Credits` int(11) NOT NULL,
  `Registration` datetime NOT NULL,
  `UserRequest` int(11) NOT NULL,
  `PeriodEndDate` date NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settop_box`
--

LOCK TABLES `settop_box` WRITE;
/*!40000 ALTER TABLE `settop_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `settop_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settop_control`
--

DROP TABLE IF EXISTS `settop_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settop_control` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `SettopName` varchar(50) NOT NULL,
  `ControlType` varchar(50) NOT NULL,
  `TTL` varchar(10) NOT NULL,
  `Message` text NOT NULL,
  `PlayChannel` varchar(100) NOT NULL,
  `Registration_Date` datetime NOT NULL,
  `ViewCheck` int(11) NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settop_control`
--

LOCK TABLES `settop_control` WRITE;
/*!40000 ALTER TABLE `settop_control` DISABLE KEYS */;
/*!40000 ALTER TABLE `settop_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms`
--

DROP TABLE IF EXISTS `sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms` (
  `Status` varchar(10) NOT NULL,
  `AutoServer` int(11) NOT NULL,
  `SendAdmin` int(11) NOT NULL,
  `SendServer` int(11) NOT NULL,
  `Start_H` int(11) NOT NULL,
  `Start_M` int(11) NOT NULL,
  `Start_S` int(11) NOT NULL,
  `End_H` int(11) NOT NULL,
  `End_M` int(11) NOT NULL,
  `End_S` int(11) NOT NULL,
  `IntervalTime` int(11) NOT NULL,
  `ActiveMsg` varchar(255) NOT NULL,
  `InactiveMsg` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms`
--

LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_log`
--

DROP TABLE IF EXISTS `sms_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_log` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `ServerName` varchar(100) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Registration` datetime NOT NULL,
  UNIQUE KEY `TID` (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_log`
--

LOCK TABLES `sms_log` WRITE;
/*!40000 ALTER TABLE `sms_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_server`
--

DROP TABLE IF EXISTS `stream_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stream_server` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `ChannelName` varchar(255) NOT NULL,
  `BroadcastingType` varchar(50) NOT NULL,
  `Resolution` varchar(10) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `LoadBalancing` varchar(2) NOT NULL,
  `MaxBitRate` varchar(10) NOT NULL,
  `MaxSession` varchar(10) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `Functions` varchar(255) NOT NULL,
  `Formats` varchar(255) NOT NULL,
  `Comments` varchar(255) NOT NULL,
  `Author` varchar(100) NOT NULL,
  `Copyright` varchar(100) NOT NULL,
  `Producer` varchar(100) NOT NULL,
  `LeadingActor` varchar(100) NOT NULL,
  `SupportingActor` varchar(100) NOT NULL,
  `Opening` varchar(255) NOT NULL,
  `SubtitlesActivated` varchar(10) NOT NULL,
  `Description` text NOT NULL,
  `ScreeningTime` varchar(100) NOT NULL,
  `Keyword` varchar(100) NOT NULL,
  `Lending` varchar(100) NOT NULL,
  `Duration` varchar(100) NOT NULL,
  `Dimensions` varchar(20) NOT NULL,
  `VideoFormats` varchar(50) NOT NULL,
  `Subtitlefile` text NOT NULL,
  `Registration_date` datetime NOT NULL,
  `SmsCheck` int(11) NOT NULL,
  `thumbnail1` varchar(255) NOT NULL,
  `thumbnail2` varchar(255) NOT NULL,
  `thumbnail3` varchar(255) NOT NULL,
  `thumbnail4` varchar(255) NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_server`
--

LOCK TABLES `stream_server` WRITE;
/*!40000 ALTER TABLE `stream_server` DISABLE KEYS */;
/*!40000 ALTER TABLE `stream_server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_server_load`
--

DROP TABLE IF EXISTS `stream_server_load`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stream_server_load` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `ServerTID` int(11) NOT NULL,
  `URL` text NOT NULL,
  `Priority` int(11) NOT NULL,
  `Device` varchar(100) NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_server_load`
--

LOCK TABLES `stream_server_load` WRITE;
/*!40000 ALTER TABLE `stream_server_load` DISABLE KEYS */;
/*!40000 ALTER TABLE `stream_server_load` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_option`
--

DROP TABLE IF EXISTS `t_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_option` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `FTP_Address` varchar(100) NOT NULL,
  `FTP_ID` varchar(50) NOT NULL,
  `FTP_PW` varchar(50) DEFAULT NULL,
  `UP_Notice` varchar(200) DEFAULT NULL,
  `UP_News` varchar(200) DEFAULT NULL,
  `UP_Background` varchar(200) DEFAULT NULL,
  `Up_Logo` varchar(255) DEFAULT NULL,
  `Up_thumbnail` varchar(255) DEFAULT NULL,
  `LoginMode` int(11) NOT NULL,
  `LogMode` int(11) NOT NULL,
  `ReloadTime` varchar(10) NOT NULL,
  `EpisodeURL` text NOT NULL,
  `TABLE_LOCK` tinyint(1) NOT NULL DEFAULT '0',
  `TempStorage` varchar(200) NOT NULL,
  `ContentsServerReloadTime` char(10) NOT NULL COMMENT 'CloudMedia 사용',
  `TaskAllocationTime` char(10) NOT NULL COMMENT 'CloudMedia 사용',
  `MaxCpu` char(5) NOT NULL COMMENT 'CloudMedia 사용 서버체크용',
  `ChainPort` char(10) NOT NULL COMMENT 'CloudMedia 사용',
  `FTP_Port` char(10) NOT NULL COMMENT 'CloudMedia 사용',
  `LiveDetection` char(2) NOT NULL COMMENT 'SV-Cloud사용',
  `FullScreenMode` char(2) NOT NULL COMMENT 'SV-Cloud사용',
  `DefaultLiveThumbnail` text NOT NULL,
  `DefaultVoDThumbnail` text NOT NULL,
  `Passive` char(10) NOT NULL,
  `CloudMediaLogMode` char(10) NOT NULL DEFAULT 'Simple' COMMENT 'CloudMedia용 로그모드',
  `HDD_Drive` char(5) NOT NULL,
  `HDD_Size` char(5) NOT NULL,
  `Web_Port` char(10) NOT NULL,
  `bTVControl` char(3) NOT NULL,
  `dbBackupLocalPath` text NOT NULL,
  `dbBackupPeriod` int(11) NOT NULL,
  `dbBackupUpload` varchar(5) NOT NULL,
  `dbBackupIP` varchar(20) NOT NULL,
  `dbBackupID` varchar(20) NOT NULL,
  `dbBackupPW` varchar(20) NOT NULL,
  `dbBackupPort` varchar(5) NOT NULL,
  `dbBackupPassive` varchar(5) NOT NULL,
  `dbBackupPath` text NOT NULL,
  `ConcurrentUsers` varchar(5) NOT NULL,
  `Advertising_Notice` int(11) NOT NULL COMMENT 'OTT',
  `Advertising_News` int(11) NOT NULL COMMENT 'OTT',
  `Background` varchar(200) NOT NULL,
  `Logo` varchar(200) NOT NULL,
  `DefaultLoginID` varchar(50) NOT NULL,
  `SMTP` varchar(100) NOT NULL,
  `Port` varchar(10) NOT NULL,
  `Sender` varchar(100) NOT NULL,
  `SSL1` int(11) NOT NULL,
  `Authentication` int(11) NOT NULL,
  `SMTP_ID` varchar(50) NOT NULL,
  `SMTP_PW` varchar(50) NOT NULL,
  `M3U_Path` varchar(255) NOT NULL,
  `apkURL` varchar(200) NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_option`
--

LOCK TABLES `t_option` WRITE;
/*!40000 ALTER TABLE `t_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tariff_plan`
--

DROP TABLE IF EXISTS `tariff_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tariff_plan` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `EID` varchar(100) NOT NULL,
  `PName` varchar(100) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `UseDefault` varchar(2) NOT NULL,
  `Registration_Date` datetime NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tariff_plan`
--

LOCK TABLES `tariff_plan` WRITE;
/*!40000 ALTER TABLE `tariff_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `tariff_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tariff_plan_selected`
--

DROP TABLE IF EXISTS `tariff_plan_selected`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tariff_plan_selected` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `ETID` int(11) NOT NULL,
  `ChannelTID` int(11) NOT NULL,
  `ChannelName` varchar(100) NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tariff_plan_selected`
--

LOCK TABLES `tariff_plan_selected` WRITE;
/*!40000 ALTER TABLE `tariff_plan_selected` DISABLE KEYS */;
/*!40000 ALTER TABLE `tariff_plan_selected` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_device`
--

DROP TABLE IF EXISTS `type_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_device` (
  `Code` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Registration` datetime NOT NULL,
  PRIMARY KEY (`Code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_device`
--

LOCK TABLES `type_device` WRITE;
/*!40000 ALTER TABLE `type_device` DISABLE KEYS */;
/*!40000 ALTER TABLE `type_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_genre`
--

DROP TABLE IF EXISTS `type_genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_genre` (
  `Code` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Registration` datetime NOT NULL,
  PRIMARY KEY (`Code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_genre`
--

LOCK TABLES `type_genre` WRITE;
/*!40000 ALTER TABLE `type_genre` DISABLE KEYS */;
/*!40000 ALTER TABLE `type_genre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_language`
--

DROP TABLE IF EXISTS `type_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_language` (
  `Code` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Registration` datetime NOT NULL,
  PRIMARY KEY (`Code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_language`
--

LOCK TABLES `type_language` WRITE;
/*!40000 ALTER TABLE `type_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `type_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_stb_group`
--

DROP TABLE IF EXISTS `type_stb_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_stb_group` (
  `Code` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Registration` datetime NOT NULL,
  PRIMARY KEY (`Code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_stb_group`
--

LOCK TABLES `type_stb_group` WRITE;
/*!40000 ALTER TABLE `type_stb_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `type_stb_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-18  4:26:46
