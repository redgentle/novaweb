-------------------------------------------------------------------------
Name��Stalker Loader
Version: v1.0.4 beta
The Stalker Loader is for importing the data from stalker database to nova database.
It could also importing the EPG data to nova database from xmltv.xml file
--------------------------------------------------------------------------
STEP 1: Unzip the "stalker_loader.zip" file.
STEP 2: Install the MySQL-python. Please refer to these commands to install.
				tar xzvf MySQL-python-1.2.3.tar.gz
				apt-get install python-setuptools
				apt-get install libmysqld-dev
				apt-get install python-dev
				python setup.py build
				python setup.py install
STEP 3: Edit the config.txt file to config the stalker_db access right and nova_db access right by Mysql.
				The configuration file is as:
				----------------------------
        #stalker_db
				dbname=stalker_db
				address=127.0.0.1
				user=root
				pass=123456
				#nova db
				dbname=ott_test
				address=127.0.0.1
				user=root
				pass=123456
				-----------------------------
STEP 4: Run the command "python dbLoader.py" to import the data.
STEP 5: Import the EPG data from xmltv.xml file.
        (1). Copy the xmltv.xml file the the loader path. This file could use different file name, please make sure to use the same file name when you import the epg data.
        (2). Run the command "python epgLoader.py clean" to clean the old epg data. Please clean the old epg data everytime before importing the new epg data.
        (3). Run the command "python epgLoader.py xmltv.xml" to clean the old epg data.
        
Note: Step 5 is not necessary, for the loader from v1.0.4, the EPG file could also be parsed from nova web portal.